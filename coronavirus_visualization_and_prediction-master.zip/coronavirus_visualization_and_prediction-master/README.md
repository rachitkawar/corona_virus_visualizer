# Novel Coronavirus Visualization and Prediction
This repository tracks the spread of the novel coronavirus, also known as SARS-CoV-2. It is a contagious respiratory virus that first started in Wuhan in December 2019. On 2/11/2020, the disease is officially named COVID-19 by the World Health Organization.

<img src='https://cdn.mos.cms.futurecdn.net/JtVH5Khvihib7dBDFY9ZDR.jpg'>
<p>Source: https://www.livescience.com/topics/live/coronavirus-live-updates </p>
